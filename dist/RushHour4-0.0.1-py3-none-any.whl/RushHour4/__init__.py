__version__ = '0.0.1'
__author__ = 'Kritik Seth, Saahil Jain'
__maintainer__ = __author__
__license__ = 'BSD 3-Clause License'
__url__ = 'https://github.com/kritikseth/RushHour4'
